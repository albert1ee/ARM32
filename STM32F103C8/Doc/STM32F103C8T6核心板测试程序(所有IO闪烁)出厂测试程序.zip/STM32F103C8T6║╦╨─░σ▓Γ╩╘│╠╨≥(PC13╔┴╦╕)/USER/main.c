//=============================================================================
//�ļ����ƣ�main.h
//���ܸ�Ҫ��STM32F103C8���ļ��
//��Ȩ���У�Դ�ع�����www.vcc-gnd.com
//��Ȩ���£�2013-02-20
//���Է�ʽ��J-Link OB ARM SW��ʽ 5MHz
//=============================================================================

//ͷ�ļ�
#include "stm32f10x.h"
#include "GPIOLIKE51.h"

//��������
void GPIO_Configuration(void);
//void GPIO_ConfigurationB(void);
//void GPIO_ConfigurationA(void);
//=============================================================================
//�ļ����ƣ�Delay
//���ܸ�Ҫ����ʱ
//����˵����nCount����ʱ����
//�������أ���
//=============================================================================

void Delay(uint32_t nCount)
{
  for(; nCount != 0; nCount--);
}


//=============================================================================
//�ļ����ƣ�main
//���ܸ�Ҫ��������
//����˵������
//�������أ�int
//=============================================================================
int main(void)
{
	  GPIO_Configuration();
//		GPIO_ConfigurationB();
//		GPIO_ConfigurationA();
    while (1)
		{
		PCout(13)=1;	PCout(14)=1;	PCout(15)=1;	
		PBout(0)=1;		PBout(1)=1;		PBout(3)=1;		PBout(4)=1;		PBout(5)=1;		PBout(6)=1;		PBout(7)=1;		PBout(8)=1;		PBout(9)=1;		PBout(10)=1;	PBout(11)=1;	PBout(12)=1;	PBout(13)=1;		PBout(14)=1;	PBout(15)=1;
		PAout(0) =1; 	PAout(1) =1;	PAout(2)=1;		PAout(3) =1;	PAout(4) =1;	PAout(5) =1;	PAout(6) =1; 	PAout(7) =1;	PAout(8) =1; 	PAout(9) =1;	PAout(10) =1;	PAout(11) =1;	PAout(12) =1;  	PAout(15) =1;
		Delay(0x6fffff);
	
		PCout(13)=0;	PCout(14)=0;	PCout(15)=0;	
		PBout(0)=0;		PBout(1)=0;	 	PBout(3)=0;		PBout(4)=0;	 	PBout(5)=0; 	PBout(6)=0; 	PBout(7)=0; 	PBout(8)=0;		PBout(9)=0; 	PBout(10)=0;	PBout(11)=0; 	PBout(12)=0;		PBout(13)=0;		PBout(14)=0;		PBout(15)=0;
		PAout(0) =0; 	PAout(1) =0;	PAout(2) =0;	PAout(3) =0;	PAout(4) =0;	PAout(5) =0;	PAout(6) =0; 	PAout(7) =0;	PAout(8) =0; 	PAout(9) =0;	PAout(10) =0;	PAout(11) =0;		PAout(12) =0;		PAout(15) =0;
		Delay(0x6fffff);
		
    }
}

//=============================================================================
//�ļ����ƣ�GPIO_Configuration
//���ܸ�Ҫ��GPIO��ʼ��
//����˵������
//�������أ���
//=============================================================================
void GPIO_Configuration(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);
	
  RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOC , ENABLE); 		
	RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOA , ENABLE);
	RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOB , ENABLE);
//=============================================================================
//LED -> PC13
//=============================================================================			 
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 |GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_13| GPIO_Pin_14 | GPIO_Pin_15;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 
  GPIO_Init(GPIOC, &GPIO_InitStructure);
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	GPIO_Init(GPIOA, &GPIO_InitStructure);
}
/*
void GPIO_ConfigurationB(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
  
  RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOB , ENABLE); 						 
//=============================================================================
//LED -> PC13
//=============================================================================			 
  GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 |GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_13| GPIO_Pin_14 | GPIO_Pin_15;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 
  GPIO_Init(GPIOB, &GPIO_InitStructure);
}

void GPIO_ConfigurationA(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
  
  RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOA , ENABLE); 						 	 
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 |GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_13| GPIO_Pin_14 | GPIO_Pin_15;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 
  GPIO_Init(GPIOA, &GPIO_InitStructure);
}
*/